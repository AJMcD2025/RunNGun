import pygame

class Boss:
    def __init__(self):
        self.x = 1100
        self.y = 200

        self.speed = 4
        self.direction = 1

        self.hp = 100

        self.shoot_timer = 0

    def update(self):

      
        self.y += self.speed * self.direction

        if self.y <= 0:
            self.direction = 1

        if self.y >= 620:
            self.direction = -1

   
        if self.y > 615:
            self.y += 2