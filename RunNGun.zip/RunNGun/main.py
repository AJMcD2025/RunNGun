import pygame
from boss import Boss

pygame.init()

screen = pygame.display.set_mode((1280,720))
pygame.display.set_caption("My Boss Game")

clock = pygame.time.Clock()

font = pygame.font.Font(None,40)
bigfont = pygame.font.Font(None,80)

playerX = 100
playerY = 300

playerSpeed = 5

playerHP = 100

bullets = []

enemyBullets = []

bulletSpeed = 15

boss = Boss()

gameOver = False
win = False

shootDelay = 0

run = True

while run:

    clock.tick(60)

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            run = False

    keys = pygame.key.get_pressed()

    if gameOver == False:

     
        if keys[pygame.K_w]:
            playerY -= playerSpeed

        if keys[pygame.K_s]:
            playerY += playerSpeed

        if keys[pygame.K_a]:
            playerX -= playerSpeed

        if keys[pygame.K_d]:
            playerX += playerSpeed

     
        if playerX < -10:
            playerX = -10

        if playerY < -10:
            playerY = -10

        if playerY > 680:
            playerY = 680

    
        if shootDelay > 0:
            shootDelay -= 1

        if keys[pygame.K_SPACE]:
            if shootDelay == 0:
                bullets.append([playerX + 30, playerY + 20])
                shootDelay = 15

     
        for b in bullets:
            b[0] += bulletSpeed

     
        for b in bullets[:]:
            if b[0] > 1300:
                bullets.remove(b)

    
        boss.update()


        boss.shoot_timer += 1

        if boss.shoot_timer > 50:

            enemyBullets.append([boss.x, boss.y + 40])

     
            if boss.hp < 50:
                enemyBullets.append([boss.x, boss.y + 60])

            boss.shoot_timer = 0

       
        for b in enemyBullets:
            b[0] -= 7

   
        for b in enemyBullets[:]:
            if b[0] < -20:
                enemyBullets.remove(b)

        bossRect = pygame.Rect(boss.x,boss.y,100,120)

        for b in bullets[:]:

            bulletRect = pygame.Rect(b[0],b[1],10,5)

            if bulletRect.colliderect(bossRect):

                bullets.remove(b)

                boss.hp -= 4

              
                if boss.hp <= 0:
                    gameOver = True
                    win = True

        playerRect = pygame.Rect(playerX,playerY,40,40)

        for b in enemyBullets[:]:

            bulletRect = pygame.Rect(b[0],b[1],10,10)

            if bulletRect.colliderect(playerRect):

                enemyBullets.remove(b)

                playerHP -= 10

                if playerHP <= 0:
                    gameOver = True


    screen.fill((25,25,25))


    pygame.draw.rect(screen,(50,150,255),(playerX,playerY,40,40))

   
    pygame.draw.rect(screen,(200,0,0),(boss.x,boss.y,100,120))

 
    pygame.draw.circle(screen,(255,255,0),(boss.x + 30,boss.y + 30),10)

 
    for b in bullets:
        pygame.draw.rect(screen,(255,255,0),(b[0],b[1],10,5))

  
    for b in enemyBullets:
        pygame.draw.rect(screen,(255,120,0),(b[0],b[1],10,10))


    pygame.draw.rect(screen,(100,100,100),(400,20,400,20))

   
    pygame.draw.rect(screen,(0,255,0),(400,20,boss.hp * 4,20))

    hpText = font.render("HP : " + str(playerHP),True,(255,255,255))
    screen.blit(hpText,(20,20))

   
    txt = font.render("WASD Move  SPACE Shoot",True,(200,200,200))
    screen.blit(txt,(20,670))

    if gameOver:

        if win:
            endText = bigfont.render("YOU WIN",True,(0,255,0))
        else:
            endText = bigfont.render("YOU LOSE",True,(255,0,0))

        screen.blit(endText,(450,300))

        restartText = font.render("Press ESC to quit",True,(255,255,255))
        screen.blit(restartText,(500,380))

       

    pygame.display.update()

pygame.quit()